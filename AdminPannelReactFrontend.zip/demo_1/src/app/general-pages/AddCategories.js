import React, { Component } from 'react'
import FormElements from '../form-elements/AddCategoriesForm';
export class Categories extends Component {
  render() {
    return (
      <div>
          <FormElements/>
        
      </div>
    )
  }
}

export default Categories;
