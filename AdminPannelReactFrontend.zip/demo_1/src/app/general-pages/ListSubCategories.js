import React, { Component } from 'react'
import SubCategoryTable  from '../tables/SubCategoryTable'

export class ListSubCategories extends Component {
  render() {
    return (
      <div>
          <SubCategoryTable/>
        
      </div>
    )
  }
}

export default ListSubCategories
