import React, { Component } from 'react'
import AddSubCategoriesForm from '../form-elements/AddSubCategoriesForm';

export class AddSubCategories extends Component {
  render() {
    return (
      <div>
          <AddSubCategoriesForm/>
        
      </div>
    )
  }
}

export default AddSubCategories;
