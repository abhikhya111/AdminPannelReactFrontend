import React, { Component } from 'react'
import AddProductsForm from '../form-elements/AddProductsForm';
import Collapsible from 'react-collapsible';
import './AddProducts.css';

export default class AddProducts extends Component {
  render() {
    return (
      <div>
          <AddProductsForm/>
          <Collapsible className='collapsable-accordian' trigger="Start here">
      <p>
        This is the collapsible content. It can be any element or React
        component you like.
      </p>
      <p>
        It can even be another Collapsible component. Check out the next
        section!
      </p>
    </Collapsible>
        
      </div>
    )
  }
}

