import React, { Component } from 'react';
import ProductTable  from '../tables/ProductTable';

export class ListProducts extends Component {
  render() {
    return (
      <div>
          <ProductTable/>
        
      </div>
    )
  }
}

export default ListProducts
