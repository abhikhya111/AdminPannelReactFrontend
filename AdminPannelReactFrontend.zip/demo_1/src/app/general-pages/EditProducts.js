import React, { Component } from 'react'
import EditProductsForm from '../form-elements/EditProductsForm';
export class EditProducts extends Component {
  render() {
    return (
      <div>
          <EditProductsForm/>
        
      </div>
    )
  }
}

export default EditProducts;
