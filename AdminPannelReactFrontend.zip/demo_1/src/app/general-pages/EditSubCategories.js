import React, { Component } from 'react'
import EditSubCategoriesForm from '../form-elements/EditSubCategoriesForm';

export class EditCategories extends Component {
  render() {
    return (
      <div>
          <EditSubCategoriesForm/>
        
      </div>
    )
  }
}

export default EditCategories;
