import React, { Component } from 'react'
import CategoryTable from '../tables/CategoryTable'

export class ListCategories extends Component {
  render() {
    return (
      <div>
          <CategoryTable/>
        
      </div>
    )
  }
}

export default ListCategories
