import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import bsCustomFileInput from 'bs-custom-file-input'
import { Link } from 'react-router-dom';

export class EditCategoriesForm extends Component {
  state = {
    startDate: new Date()
  };
 
  handleChange = date => {
    this.setState({
      startDate: date
    });
  };
  componentDidMount() {
    bsCustomFileInput.init()
  }
  render() {
    return (
      <div>
        <div className="row">
          <div className="col-12 grid-margin">
            <div className="card">
              <div className="card-body">
                <h3 >Edit Category</h3>
                <form className="form-sample">
                  <p className="card-description"> </p>
                  <div className="row">
                    <div className="col-md-6">
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Category ID</label>
                        <div className="col-sm-9">
                        <Form.Control  type="text" placeholder='Enter Category ID'/>
                        </div>
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Category Name</label>
                        <div className="col-sm-9">
                        <Form.Control type="text" placeholder='Enter Category Name'/>
                        </div>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                    <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Slug</label>
                        <div className="col-sm-9">
                        <Form.Control type="text" placeholder='Enter Slug'/>
                        </div>
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                    <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Description</label>
                        <div className="col-sm-9">
                        <Form.Control type="text" placeholder='Enter category description'/>
                        </div>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                    <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Meta Title</label>
                        <div className="col-sm-9">
                        <Form.Control type="text" placeholder='Enter Meta Title'/>
                        </div>
                      </Form.Group>
                    </div>
                    <div className="col-md-6">
                      <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Upload Image</label>
                        <div className="col-sm-9">
                        <Form.Control type="file" className="btn btn-success" placeholder='Select Image' style={{width:"275px"}}/>
                        </div>
                      </Form.Group>
                    </div>
                  </div>
                  <div className="row">
                  <div className="col-md-6">
                    <Form.Group className="row">
                        <label className="col-sm-3 col-form-label">Meta Description</label>
                        <div className="col-sm-9">
                        <Form.Control as="textarea" rows={10} placeholder='Enter Meta Description'/>
                        </div>
                      </Form.Group>
                    </div>
                    
                  </div>
                  <button type="submit" className="btn btn-gradient-primary mr-2">Submit</button>
                  <button className="btn btn-info"><Link  style={{color: "white",textDecoration:"none"}} to="/categories">Cancel</Link></button>
                 
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default EditCategoriesForm
