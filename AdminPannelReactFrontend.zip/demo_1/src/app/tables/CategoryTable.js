import React, { Component } from 'react'
import { Link } from 'react-router-dom';

export class CategoryTable extends Component {
  render() {
    return (
      <div>
        <div className="page-header">
          {/* <h3 className="page-title"> Basic Tables </h3> */}
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><a href="!#" onClick={event => event.preventDefault()}>Tables</a></li>
              <li className="breadcrumb-item active" aria-current="page">Basic tables</li>
            </ol>
          </nav>
        </div>
        <div className="row">
          <div className="col-lg-12 grid-margin stretch-card">
           
          
            <div className="card">
              <div className="card-body">
                <h4 className="card-title">Categories</h4>
                <button type="submit" className="btn btn-gradient-info mr-2 mt-3 mb-3"><Link style={{color: "white",textDecoration:"none"}} to="/addCategories" >Add Category</Link></button>

                {/* <p className="card-description"> Add className <code>.table-hover</code>
                </p> */}
                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Slug</th>
                        <th>Description</th>
                        <th>Meta Title</th>
                        <th>Meta Description</th>
                        <th>Meta Keyword</th>
                        <th>Image</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Jacob</td>
                        <td>Photoshop</td>
                        <td className="text-danger"> 28.76% <i className="mdi mdi-arrow-down"></i></td>
                        <td><label className="badge badge-danger">Pending</label></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                            
                            <button  type="submit" className="btn btn-gradient-success mr-2"><Link  style={{color: "white",textDecoration:"none"}} to="/editCategories">Edit</Link></button>
                            <button  className="btn btn-gradient-danger mr-2">Delete</button>

                        </td>
                      </tr>
                      <tr>
                        <td>Messsy</td>
                        <td>Flash</td>
                        <td className="text-danger"> 21.06% <i className="mdi mdi-arrow-down"></i></td>
                        <td><label className="badge badge-warning">In progress</label></td>
                      </tr>
                      <tr>
                        <td>John</td>
                        <td>Premier</td>
                        <td className="text-danger"> 35.00% <i className="mdi mdi-arrow-down"></i></td>
                        <td><label className="badge badge-info">Fixed</label></td>
                      </tr>
                      <tr>
                        <td>Peter</td>
                        <td>After effects</td>
                        <td className="text-success"> 82.00% <i className="mdi mdi-arrow-up"></i></td>
                        <td><label className="badge badge-success">Completed</label></td>
                      </tr>
                      <tr>
                        <td>Dave</td>
                        <td>53275535</td>
                        <td className="text-success"> 98.05% <i className="mdi mdi-arrow-up"></i></td>
                        <td><label className="badge badge-warning">In progress</label></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default CategoryTable
