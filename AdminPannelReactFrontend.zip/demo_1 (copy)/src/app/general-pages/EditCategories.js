import React, { Component } from 'react'
import EditCategoriesForm from '../form-elements/EditCategoriesForm';
export class EditCategories extends Component {
  render() {
    return (
      <div>
          <EditCategoriesForm/>
        
      </div>
    )
  }
}

export default EditCategories;
