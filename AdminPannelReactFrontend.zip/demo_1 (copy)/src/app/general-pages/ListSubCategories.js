import React, { Component } from 'react'
import CategoryTable from '../tables/CategoryTable'

export class ListSubCategories extends Component {
  render() {
    return (
      <div>
          <CategoryTable/>
        
      </div>
    )
  }
}

export default ListSubCategories
